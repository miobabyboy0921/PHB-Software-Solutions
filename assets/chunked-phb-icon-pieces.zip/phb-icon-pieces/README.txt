PHB icon, split into pieces for Canva

The P-H-B letters are not a font. They are drawn shapes (rounded lines, 13 units thick
on a 200 x 200 badge), so they are supplied here as separate pieces.

Option 1 - one file, every piece separate (recommended)
  In Canva: Create a design > Import file > phb-icon-pieces-canva.pdf
  The badge, P, H, B and red circuit line each become their own element, already in position.

Option 2 - separate SVG files
  Upload all five SVGs. They share the same 200 x 200 canvas, so if you set each to the same
  size and position (e.g. 500 x 500 at the same x/y) they line up exactly.
    01-badge.svg          dark slate rounded square  #2D3142
    02-letter-P.svg       white                       #FFFFFF
    03-letter-H.svg       white (two uprights)        #FFFFFF
    04-letter-B.svg       white                       #FFFFFF
    05-circuit-line.svg   bright red crossbar + nodes #E63946 (node centers #2D3142)

Layer order, bottom to top: badge, P, H, B, circuit line.
If you need a similar typed font: Quicksand Bold is the closest in Canva, but it will not match exactly.
