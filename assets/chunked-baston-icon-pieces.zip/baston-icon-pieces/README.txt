BASTON icon, split into pieces for Canva

The icon is drawn shapes, not a font, so it is supplied here as separate pieces.

Option 1 - one file, every piece separate (recommended)
  In Canva: Create a design > Import file > baston-icon-pieces-canva.pdf
  Each piece becomes its own element, already in position.

Option 2 - separate SVG files
  Upload all eight SVGs. They share the same 200 x 200 canvas, so if you set each to the same
  size and position (e.g. 500 x 500 at the same x/y) they line up exactly.
    01-outer-ring.svg     near black circle        #1E1E24
    02-badge.svg          dark slate circle        #2D3142
    03-inner-ring.svg     thin ring                #4A4E5D
    04-cane.svg           white cane               #FFFFFF
    05-cane-tip.svg       bright red tip           #E63946
    06-wave-small.svg     bright red               #E63946
    07-wave-middle.svg    deep red                 #A61C2C
    08-wave-large.svg     gray                     #8A8FA3

Layer order, bottom to top: outer ring, badge, inner ring, cane, cane tip, waves.
